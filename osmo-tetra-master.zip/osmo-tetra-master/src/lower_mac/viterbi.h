#ifndef VITERBI_H
#define VITERBI_H

void viterbi_dec_sb1_wrapper(const uint8_t *in, uint8_t *out, unsigned int sym_count);

#endif /* VITERBI_H */
